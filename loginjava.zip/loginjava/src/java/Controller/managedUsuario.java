/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import EJB.UsuarioFacadeLocal;
import Entity.Persona;
import Entity.Tipo;
import Entity.Usuario;
import java.io.Serializable;
import java.util.List;
import javax.annotation.ManagedBean;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.persistence.Entity;

/**
 *
 * @author Ing. Guillermo Antonio Pérez
 */
@Entity
@ManagedBean
@SessionScoped
public class managedUsuario implements Serializable{
    @EJB
    private UsuarioFacadeLocal usuarioFacade;
    private List<Usuario> listaUsuario;
    private Usuario usuario;
    private Persona persona;
    private Tipo tipo;
    
    public List<Usuario> getListaUsuario(){
        this.listaUsuario = this.usuarioFacade.findAll();
        return listaUsuario;
    }

    public UsuarioFacadeLocal getUsuarioFacade() {
        return usuarioFacade;
    }

    public void setUsuarioFacade(UsuarioFacadeLocal usuarioFacade) {
        this.usuarioFacade = usuarioFacade;
    }

    
    public void setListaUsuario(List<Usuario> listaUsuario) {
        this.listaUsuario = listaUsuario;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Persona getPersona() {
        return persona;
    }

    public void setPersona(Persona persona) {
        this.persona = persona;
    }

    public Tipo getTipo() {
        return tipo;
    }

    public void setTipo(Tipo tipo) {
        this.tipo = tipo;
    }
    
    @PostConstruct
    public void init(){
        this.persona = new Persona();
        this.tipo = new Tipo();
        this.usuario = new Usuario();
    }

    public String validar() {
        String ruta = "";
        Usuario valor;
        try {
            valor = this.usuarioFacade.acceder(this.usuario);
            if (valor != null) {
                ruta = "datos";
            } else {
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Usuario No Registrado", "Admin"));
            }
        } catch (Exception ex) {
            throw ex;
        }
        return ruta;
    }
}
